/* Name: James Farrow
 * Date: 04/05/2025
 *Course: CS 210 Programming Languages
 */


#include <iostream>
#include <iomanip>
using namespace std;

class BankingApplication {
private:
	double originalInvestment;
	double monthlyDeposit;
	double Rate;
	int Years;

public:
	void input(){
		cout << "Original: "; cin >> originalInvestment;
		cout << "Deposit: "; cin >> monthlyDeposit;
		cout << "Rate: "; cin >> Rate;
		cout << "Years: "; cin >> Years;
	}

	void noDeposit(){
		double balance = originalInvestment;
		cout << "\nThere are no monthly depoisits: \n";
		cout << "Year\tYear End Balance\tIntersts Earned\n";
		for (int year = 1; year <= Years; ++year){
			double interest = balance * (Rate / 100);
			balance += interest;
			cout << year << "\t$" << fixed << setprecision(2) << balance
				<< "\t\t$" << interest << endl;
		}
	}

	void withDeposit(){
		double balance = originalInvestment;
		cout << "\nBalance and Interest with a monthly deposit: \n";
		cout << "Year\tYear End Balance\tInterest Earned\n";
		for (int year = 1; year <= Years; ++year){
			double annualInterest = 0.0;
			for (int month = 1; month <= 12; ++month){
				balance += monthlyDeposit;
				double interest = balance * ((Rate / 100) / 12);
				balance += interest;
				annualInterest += interest;
			}
			cout << year << "\t$" << fixed << setprecision(2) << balance
				 << "\t\t$" << annualInterest << endl;
		}
	}
};

int main(){
	BankingApplication calculator;
	calculator.input();
	calculator.noDeposit();
	calculator.withDeposit();
	return 0;
}
