package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {

	@GetMapping("/hash")
	public String getHash() {
		String data = "Welcome Artemix Financial";
		String checksum = ChecksumUtil.generateChecksum(data);
		return "Data: " + data + "<br>SHA-256 Checksum: " + checksum;
	}
}