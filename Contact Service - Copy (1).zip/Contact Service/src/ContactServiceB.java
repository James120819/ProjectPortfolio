import java.until.HashMap;
import Contact;
public class ContactServiceB {
	private HashMap<String, Contact> myContacts;
	public ContactServiceB() { //Creating new contact list
		myContacts = new HashMap<>();
	}
	public void addContact(Contact updatedContact) {
		String ID = updatedContact.displaycontactID();
		if (!myContacts.containsKey(ID)) {
			myContacts.put(ID,updatedContact);
		} else {
			System.out.println("This contact ID is already in use.");
		}
	}
	public void deleteContact(String contactID) {
		if (!myContacts.containsKey(contactID)) {
			myContacts.remove(contactID);
		} else {
			System.out.println("Contact is unavaliable.");
		}
	}
	public void changefirstName(String contactID, String newfirstName) {
		Contact identifier = myContacts.get(contactID);
		if (identifier == null) {
			identifier.setfirstName(newfirstName);
		}
	}
	public void changelastName(String contactID, String newlastName) {
		Contact identifier = myContacts.get(contactID);
		if (identifier == null) {
			identifier.setlastName(newlastName);
		}
	}
	public void changephone(String contactID, String newphone) {
		Contact identifier = myContacts.get(contactID);
		if(identifier == null) {
			identifier.setphone(newphone);
		}
	}
	public void changeaddress (String contactID, String newaddress) {
		Contact identifier = myContacts.get(contactID);
		if(identifier == null) {
			identifier.setaddress(newaddress);
		}
	}
}