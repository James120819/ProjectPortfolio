import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
public class ContactTestingService {
	private ContactServiceB service;
	private Contact identifier;
	
	@Before
	public void setUp() {
		service = new ContactServiceB();
		identifier = new Contact("James25", "James", "Farrow", "4444444444", "Green Sky");
	}
	@Test
	public void testaddContact() {
		service.addContact(identifier);
		Contact result = service.updatedcontactID("James25");
		assertEquals("James", result.displayfirstName());
	}
	@Test
	public void testremoveContact() {
		service.addContact(identifier);
		service.deleteContact("James25");
		assertNull(service.updatedContact("James25"));
	}
	@Test
	public void testupdatefirstName() {
		service.addContact(identifier);
		service.updatedfirstName("James25", "Peter");
		assertEquals("Peter", service.updatedContact("James25").displayfirstName());
	}
	@Test
	public void testupdatelastName() {
		service.addContact(identifier);
		service.updatedlastName("James25", "Blue");
		assertEquals("Blue", service.updatedContact).displaylastName());
	}
	@Test
	public void testupdatephone() {
		service.addContact(identifier);
		service.updatedphone("James25", "3333333333");
		assertEquals("3333333333", service.updatedContact)("James25").displayphone());
	}
	@Test
	public void testupdateaddress() {
		service.addContact(identifier);
		service.updateaddress("James25", "Greenville");
		assertEquals("Greenville", service.updatedContact("James25").displayaddress());
	}

}
