import org.junit.Test;
import static org.junit.Assert.*;
public class ContactTesting {
	//Running test for important contacts
	@Test
	public void testImportantContact() {
		Contact test = new Contact ("James25", "James", "Farrow", "4444444444", "Green Sky");
		
		assertEquals("James25", test.displaycontactID());
		assertEquals("James", test.displayfirstName());
		assertEquals("Farrow", test.displaylastName());
		assertEquals("4444444444", test.displayphone());
		assertEquals("Green Sky", test.displayaddress());
		
	}
	@Test
	public void testContactPhoneSmall() {
		Contact test = new Contact ("James28", "James", "Farrow", "4-6-8", "Green Sky");
		assertNotEquals("4-6-8", test.displayphone()); //Testing invalid phone number for the program
		
	}
	@Test
	public void testaddressSmall() {
		Contact test = new Contact ("James30", "James", "Farrow", "4444444444", "Address is too small.");
		assertNotEquals("Addressis too small", test.displayaddress());
	}

}