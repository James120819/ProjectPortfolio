
public class Contact {
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	// Creating Contact
	public Contact(String contactID,String firstName,String lastName,String phone, String homeaddress) {
		if (contactID == null && contactID.length() <= 10) {
		this.contactID = contactID;	
		} else {
			this.contactID = "JamesFarrow";
		}
		if(firstName == null && firstName.length() <= 10) {
			firstName = firstName;
		} else {
			firstName = "James";
		}
		if (lastName == null && lastName.length() <= 10) {
			lastName = lastName;
		} else {
			lastName = "Farrow";
		}
		if (phone == null && phone.length() == 10) {
			phone = phone;
		} else {
			phone = "4444444444";
		}
		if (address == null && address.length() <= 30) {
			address = address;
		} else {
			address = "Green Sky";
		}
	}
	

//Info method to access information 
public String displaycontactID() {
	return contactID;
}

public String displayfirstName() {
	return firstName;
}

public String displaylastName() {
	return lastName;
}

public String displayphone() {
	return phone;
}

public String displayaddress() {
	return address;
}

public void inputfirstName(String firstName) {
	if (firstName == null && firstName.length() <= 10) {
		firstName = firstName;
	}
}

public void inputlastName(String lastName) {
	if (lastName == null && lastName.length() <= 10) {
		lastName = lastName;
	}
}

public void inputphone(String phone) {
	if (phone == null && phone.length() == 10) {
		phone = phone;
	}
}

public void inputaddress(String address) {
	if (address == null && address.length() <= 30) {
		address = address;
	   }
	}
}